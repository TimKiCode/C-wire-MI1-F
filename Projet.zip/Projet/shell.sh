Rayko
rayko0
En ligne

Gxts — 20/10/2024 22:59
https://youtu.be/KxzC-O7LrVU?si=iXTl9no0f3SfA33Z
YouTube
Sixquatre
Les MEILLEURS SPAWNKILLS de TOUTES les Maps Ranked
Image
Rayko — 20/10/2024 22:59
Let's goo
Merci
Rayko — 21/10/2024 20:07
ça joue?
Gxts — 21/10/2024 20:07
j'aimerais
mais ça dl
c long
Rayko — 21/10/2024 20:07
ah oui shit
okay
Gxts — 21/10/2024 20:07
j'ai reglé le prblm au moins
Rayko — 21/10/2024 20:07
aaaahh let's gooo
Gxts — 21/10/2024 20:24
je peux jouer dans genre 20min
Rayko — 21/10/2024 20:37
Dacc
Gxts — 21/10/2024 20:45
c good
Rayko a commencé un appel qui a duré 16 minutes. — 21/10/2024 20:46
Gxts — 22/10/2024 18:06
https://youtube.com/clip/Ugkxgu92FqscNTypZHvdKbyUybITRzwIOVBb?si=3MML8gCTb-5Mpvy7
YouTube
✂️ Avis sur les main
Image
Rayko — 22/10/2024 18:09
Gxts — 22/10/2024 18:09
🤣
regarde le clip que je t(ai envoyé
Rayko — 22/10/2024 18:10
Doc main
Gxts — 22/10/2024 18:10
lets gooo
Rayko — 22/10/2024 18:10
Rook
Nan il abuse
Caveira okay je comprends
Gxts — 22/10/2024 18:11
c reel
Rayko — 05/11/2024 23:31
https://www.millenium.org/guide/419010.html
Millenium FR
Tier list Pokémon TCG Pocket : Les meilleurs decks à faire pour rou...
Dans Pokémon TCG Pocket, nous pouvons créer nos propres decks avec les cartes que nous avons collectionnées. Toutefois, certains d'entre eux sont plus forts que d'autres comme le deck Mewtwo/Gardevoir ou Pikachu. Pour vous aider à les connaitre, nous vous proposons la tier list du format actuel.
Image
https://www.pokemon-zone.com/decks/
Pokemon Zone
Best Decks & Tier List of Pokémon TCG Pocket | Pokemon Zone
Discover all the main archetypes of Pokémon TCG Pocket and suggested decklists to build the best decks in the game.
Rayko — 05/11/2024 23:57
https://www.pokemon-zone.com/game-guides/
Pokemon Zone
Pokemon Zone
Game guides for Pokémon TCG Pocket | Pokemon Zone
All the guides for Pokémon TCG Pocket: beginner's guide, in-game economy, best cards, wonder pick... and many more!
Game guides for Pokémon TCG Pocket | Pokemon Zone
Gxts — 06/12/2024 17:39
ça voc ?
Rayko a commencé un appel qui a duré 3 minutes. — 06/12/2024 17:39
Gxts — 16/12/2024 10:58
Image
Gxts — 16/12/2024 11:14
Image
Gxts — Hier à 12:17
Image
Image
Image
Image
Image
Rayko — Hier à 12:24
https://cy.deltahmed.fr/posts/DS1-2022-2023_Histoire-du-design-DSp2s1/
Cy Δ Cours
DS1 2022 2023 Histoire-du-design-DS PREING2 S1
Télécharger le DS1 2022 2023 en pdf
Gxts — Hier à 13:19
jsuis de retour
Rayko — Hier à 13:21
J'arrive bientôt
Gxts — Hier à 13:37
#!/bin/bash

Capturer le temps de début
start_time=$(date +%s)

Exécuter ton code en C (remplace ./ton_programme par ton exécutable)
./ton_programme input_file.txt

Capturer le temps de fin
end_time=$(date +%s)

Calculer le temps de traitement
execution_time=$((end_time - start_time))

Afficher le résultat
echo "Temps de traitement : $execution_time secondes"
Rayko — Hier à 15:02
Image
Rayko — Hier à 15:10
https://www.whitescreen.online/
White screen | Online Tool
Online tool to show white fullscreen page. Use as a light source for zoom calls or to test monitor, to copy drawings, to make a flipbook, to focus yourself.
Image
Gxts — Hier à 15:30
Image
Gxts — Aujourd’hui à 20:07
Je suis paré au combat
Rayko — Aujourd’hui à 20:11
En théorie oui mais je viens de sortir de table
Laisse moi 10 mins de guitare
Gxts — Aujourd’hui à 20:11
vsyyy
Rayko — Aujourd’hui à 20:11
J'exerce mon droit de veto
Gxts — Aujourd’hui à 20:12
mdrr
Rayko a commencé un appel. — Aujourd’hui à 20:28
Gxts — Aujourd’hui à 20:36
$@
$#
Gxts — Aujourd’hui à 21:30
Rayko — Aujourd’hui à 21:33
echo "                                                  "
echo "  __                  _    __     __"
echo " |  )      \ \      / /  | |  /   \   | __|"
echo " | /        \ \ /\ / /   | |  | () )  | __|"
echo " | _   ()  \ V  V /    | |  |    \   | |_"
echo " _)         _/_/     ||  ||_\  |___|"
#!/bin/bash

# Nom du dossier à vérifier (chemin relatif)
tmp="tmp"
graphs="graphs"
exec="CodeC/exec"
Afficher plus
shell.sh
4 Ko
Gxts — Aujourd’hui à 21:43
#!/bin/bash

# Nom du dossier à vérifier (chemin relatif)
tmp="tmp"
graphs="graphs"
exec="CodeC/exec"
Afficher plus
shell.sh
4 Ko
﻿
#!/bin/bash

# Nom du dossier à vérifier (chemin relatif)
tmp="tmp"
graphs="graphs"
exec="CodeC/exec"
combined="$2-$3"
fichier="$1"

tmp_file="$tmp/tmp.txt"
tmp_file2="$tmp/tmp2.txt"

touch "$tmp_file"
touch "$tmp_file2"

echo "     ____      __          __   _    ____     _____ "
echo "    /  __)     \ \        / /  | |  /  _ \   | ____|"
echo "    | /     __  \ \ /\/\ / /   | |  | (_) |  | |_"
echo "    | |    (__)  \ V    V /    | |  |    /   | __|"
echo "    | \__         \      /     | |  |  _ \   | |___"
echo "    \____)         \_/\_/      |_|  |_| \_\  |_____|"
echo ""

for arg in "$@"; do
	if [[ "$arg" == "-h" ]]; then
		echo "Vous avez utilisez la commande "-h" voici une aide sur le fonctionnement du programme."
		exit 0
	fi
done

# Vérification du nombre d'arguments
if [ "$#" -gt 4 ]; then
	echo "Erreur : Le nombre d'arguments ne doit pas dépasser 4."
	echo "Utilisez la commande \"-h\" pour afficher l'aide."
	exit 1
fi

if [ ! -f "$fichier" ]; then
    echo "Erreur : Le fichier spécifié \"$fichier\" n'existe pas dans le dossier Input."
    exit 1
fi

function hvbcomp {
	tail -n +2 "$tmp_file"  | cut -d ';' -f 2- | awk -F';' '{ if($1 !~ /-/ && $2 ~ /-/ ) print $1, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"

}

function hvacomp {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($2 !~ /-/ && $3 ~ /-/) print $2, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}


function lvall {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/) print $3, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}
	
function lvcomp {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/ && $5 ~ /-/ ) print $3, $(NF-1), $NF }'| awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}

function lvindiv {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/ && $4 ~ /-/) print $3, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}

# Vérification des dossiers temporaires et graphiques
if [ -d "$tmp" ]; then
	if [ -n "$(ls -A "$tmp")" ]; then
		rm -rf "$tmp"/*
	fi
else
	mkdir "$tmp"
fi

if [ ! -d "$graphs" ]; then
	mkdir "$graphs"
fi

# Vérification de l'exécutable
if [ ! -f "$exec" ]; then
	echo "Erreur sur l'exécutable."
	echo "Temps de traitement : 0s 0ms"
	exit 1
fi

start_time=$(date +%s%3N)

if [ -n "$4" ]; then
	echo "Vérification de la présence du numéro de centrale $4 dans le fichier temporaire."
	if grep "^$4;" "$fichier" > /dev/null; then
		echo "Centrale présente"
		grep "^$4;" "$fichier" > "$tmp_file"
	else
		echo "Erreur : Le numéro de centrale $4 n'est pas présent dans le fichier"
		exit 1
	fi
else
	cat "$fichier" > "$tmp_file"

fi

case "$combined" in
"hvb-comp") hvbcomp;;
"hva-comp") hvacomp;;
"lv-all") lvall;;
"lv-comp") lvcomp;;
"lv-indiv") lvindiv;;
*) echo -e "Mauvaise saisie des arguments! Utilisez la commande \"-h\" pour afficher l'aide.\nTemps de traitement : 0s 0ms"
exit;;
esac

cd "CodeC" || { echo "Impossible d'accéder au dossier CodeC"; exit 1; }
make
if [ $? -ne 0 ]; then
	echo "Erreur de compilation"
	echo "Temps de traitement : 0s 0ms"
	exit 1
fi

echo "Compilation réussie !"

cd ..

chmod +x ./CodeC/exec

./CodeC/exec "$tmp_file2" "$combined"

if [ "$combined" = "lv-all" ]; then
	touch tmp/sorted.txt
	sort -k4,4n Output/calc_lv-all.txt > tmp/sorted.txt
	touch tmp/smallest.txt
	touch tmp/largest.txt
	touch Output/result.txt
	head -n 10 tmp/sorted.txt > tmp/smallest.txt
	tail -n 10 tmp/sorted.txt > tmp/largest.txt
	cat tmp/smallest.txt tmp/largest.txt > Output/result.txt
fi

end_time=$(date +%s%3N)
execution_time=$((end_time - start_time))
seconds=$((execution_time / 1000))
milliseconds=$((execution_time % 1000))

echo "Temps de traitement : ${seconds}s ${milliseconds}ms"