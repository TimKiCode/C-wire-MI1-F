#!/bin/bash
clear
# Nom du dossier à vérifier (chemin relatif)
tmp="tmp"
graphs="graphs"
exec="CodeC/exec"
combined="$2-$3"
fichier="$1"

tmp_file="$tmp/tmp.txt"
tmp_file2="$tmp/tmp2.txt"

touch "$tmp_file"
touch "$tmp_file2"

for arg in "$@"; do
	if [[ "$arg" == "-h" ]]; then
		echo "Il vous faut d'abord avoir un fichier à traiter dans le dossier Input/"
        	echo " "
		echo "Puis exécuter le fichier shell nommé c-wire.sh puis passer en 1er argument le chemin de votre fichier"
		echo "par exemple Input/c-wire_v00.dat puis en 2eme et 3eme l'une des possibilités suivantes : hvb comp, hva comp, lv all, lv comp, lv indiv."
		echo "Enfin vous pouvez rajouter un 4eme argument pour filtrer en fonction d'une centrale précise."
		echo "Par exemple : /c-wire.sh Input/c-wire_v25.dat lv all 1"
		exit 0
	fi
done

# Vérification du nombre d'arguments
if [ "$#" -gt 4 ]; then
	echo "Erreur : Le nombre d'arguments ne doit pas dépasser 4."
	echo "Utilisez la commande \"-h\" pour afficher l'aide."
	exit 1
fi

if [ ! -f "$fichier" ]; then
    echo "Erreur : Le fichier spécifié \"$fichier\" n'existe pas dans le dossier Input."
    exit 1
fi

function hvbcomp {
	tail -n +2 "$tmp_file"  | cut -d ';' -f 2- | awk -F';' '{ if($1 !~ /-/ && $2 ~ /-/ ) print $1, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"

}

function hvacomp {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($2 !~ /-/ && $3 ~ /-/) print $2, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}


function lvall {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/) print $3, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}
	
function lvcomp {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/ && $5 ~ /-/ ) print $3, $(NF-1), $NF }'| awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}

function lvindiv {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/ && $4 ~ /-/) print $3, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}

# Vérification des dossiers temporaires et graphiques
if [ -d "$tmp" ]; then
	if [ -n "$(ls -A "$tmp")" ]; then
		rm -rf "$tmp"/*
	fi
else
	mkdir "$tmp"
fi

if [ ! -d "$graphs" ]; then
	mkdir "$graphs"
fi

cd "CodeC" || { echo "Impossible d'accéder au dossier CodeC"; exit 1; }
make
if [ $? -ne 0 ]; then
	echo "Erreur de compilation"
	echo "Temps de traitement : 0s 0ms"
	exit 1
fi

echo "Compilation réussie !"

clear

echo "     ____"
echo "    /  __)"
echo "    | /"
echo "    | |"
echo "    | \\__"
echo "    \____)"
echo ""

sleep 0.5
clear

echo "     ____"
echo "    /  __)"
echo "    | /     __"
echo "    | |    (__)"
echo "    | \\__"
echo "    \____)"
echo ""

sleep 0.5
clear

echo "     ____      __          __"
echo "    /  __)     \\ \\        / /"
echo "    | /     __  \\ \\ /\\/\\ / /"
echo "    | |    (__)  \ V    V /"
echo "    | \\__         \\      /"
echo "    \____)         \\_/\\_/"
echo ""

sleep 0.5
clear

echo "     ____      __          __   _"
echo "    /  __)     \\ \\        / /  | |"
echo "    | /     __  \\ \\ /\\/\\ / /   | |"
echo "    | |    (__)  \\ V    V /    | |"
echo "    | \\__         \\      /     | |"
echo "    \____)         \\_/\\_/      |_|"
echo ""

sleep 0.5
clear

echo "     ____      __          __   _    ____"
echo "    /  __)     \\ \\        / /  | |  /  _ \\"
echo "    | /     __  \\ \\ /\\/\ / /   | |  | (_) |"
echo "    | |    (__)  \\ V    V /    | |  |    /"
echo "    | \\__         \\      /     | |  | |\ \\"
echo "    \____)         \\_/\\_/      |_|  |_| \_\\"
echo ""

sleep 0.5
clear

echo "     ____      __          __   _    ____     _____"
echo "    /  __)     \\ \\        / /  | |  /  _ \\   | ____|"
echo "    | /     __  \\ \\ /\\/\\ / /   | |  | (_) |  | |_"
echo "    | |    (__)  \\ V    V /    | |  |    /   | __|"
echo "    | \\__         \\      /     | |  | |\ \\   | |___"
echo "    \____)         \\_/\\_/      |_|  |_| \_\\  |_____|"
echo ""

sleep 0.5
clear

echo "     ____      __          __   _    ____     _____"
echo "    /  __)     \\ \\        / /  | |  /  _ \\   | ____|"
echo "    | /     __  \\ \\ /\\/\\ / /   | |  | (_) |  | |_"
echo "    | |    (__)  \\ V    V /    | |  |    /   | __|"
echo "    | \\__         \\      /     | |  | |\ \\   | |___     __   __   __"
echo "    \\____)         \\_/\\_/      |_|  |_| \_\\  |_____|   (__) (__) (__)"
echo ""

cd ..

chmod +x ./CodeC/exec

start_time=$(date +%s%3N)

if [ -n "$4" ]; then
	echo "Vérification de la présence du numéro de centrale $4 dans le fichier temporaire."
	# Exécuter grep et remplir le fichier temporaire
    	grep "^$4;" "$fichier" > "$tmp_file"
    
    	# Vérifier si le fichier temporaire est vide
    	if [ -s "$tmp_file" ]; then
       		echo "Centrale présente"
	else
		echo "Erreur : Le numéro de centrale $4 n'est pas présent dans le fichier"
		exit 1
	fi
else
	tmp_file="$1"

fi

case "$combined" in
"hvb-comp") hvbcomp;;
"hva-comp") hvacomp;;
"lv-all") lvall;;
"lv-comp") lvcomp;;
"lv-indiv") lvindiv;;
*) echo -e "Mauvaise saisie des arguments! Utilisez la commande \"-h\" pour afficher l'aide.\nTemps de traitement : 0s 0ms"
exit;;
esac


./CodeC/exec "$tmp_file2" "$combined"

if [ "$combined" = "lv-all" ]; then
	touch tmp/sorted.txt
	sort -k4,4n -T /tmp Output/calc_lv-all.txt > tmp/sorted.txt
	touch tmp/smallest.txt
	touch tmp/largest.txt
	touch Output/result.txt
	head -n 10 tmp/sorted.txt > tmp/smallest.txt
	tail -n 10 tmp/sorted.txt > tmp/largest.txt
	cat tmp/smallest.txt tmp/largest.txt > Output/result.txt
	# Génération du graphique
	chmod 777 plot.gnuplot
	chmod 777 Output/result.txt
	chmod 777 graphs
	gnuplot plot.gnuplot
	mv Output/result.txt Output/lv_all_minmax.txt
	if [ -n "$4" ]; then
		mv graphs/bar_chart.png graphs/lv_all_minmax_$4_graph.png
		mv Output/lv_all_minmax.txt Output/lv_all_minmax_$4.txt
	else
		mv graphs/bar_chart.png graphs/lv_all_minmax_graph.png
	fi	
fi

if [ "$combined" ]; then
	sort -n -k3 -T /tmp Output/calc_$combined.txt -o Output/calc_$combined.txt
	if [ -n "$4" ]; then
		mv Output/calc_$combined.txt Output/${combined}_$4.txt
	else
		mv Output/calc_$combined.txt Output/$combined.txt
	fi	

	
fi

end_time=$(date +%s%3N)
execution_time=$((end_time - start_time))
seconds=$((execution_time / 1000))
milliseconds=$((execution_time % 1000))
echo "Temps de traitement : ${seconds}s ${milliseconds}ms"