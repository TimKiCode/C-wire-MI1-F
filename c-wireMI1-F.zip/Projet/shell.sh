#!/bin/bash
clear
#Name of the folder to check (relative path)
tmp="tmp"
graphs="graphs"
exec="CodeC/exec"
combined="$2-$3"
file="$1"
YELLOW='\033[0;33m' # Yellow color
RED='\033[1;31m' # Red color
GREEN='\033[0;32m' # Green color
BLUE='\033[0;34m' # Blue color
NC='\033[0m' # No color (reset)
tmp_file="$tmp/tmp.txt"
tmp_file2="$tmp/tmp2.txt"

touch "$tmp_file"
touch "$tmp_file2"

#Help option "-h"
for arg in "$@"; do
	if [[ "$arg" == "-h" ]]; then
		echo -e "    ${BLUE}✻--------------------------------✻"
		echo -e "    | Bienvenue dans l'espace d'aide |"
		echo -e "    ✻--------------------------------✻\n${NC}"
		echo -e "    ${YELLOW}Ⅰ Il vous faut d'abord avoir un fichier à traiter dans le dossier Input/"
        	echo -e "    Ⅱ Puis exécuter le fichier shell nommé c-wire.sh puis passer en 1er argument le chemin de votre fichier"
		echo -e "    Ⅲ Par exemple Input/c-wire_v00.dat puis en 2ème et 3ème l'une des possibilités suivantes : hvb comp, hva comp, lv all, lv comp, lv indiv."
		echo -e "    Ⅳ Enfin vous pouvez rajouter un 4ème argument pour filtrer en fonction d'une centrale précise.\n${NC}"
		echo -e "    ${GREEN}☺ Par exemple : /c-wire.sh Input/c-wire_v25.dat lv all 1\n${NC}"
		exit 0
	fi
done

#Checking the number of arguments
if [ "$#" -gt 4 ]; then
	echo -e "    ${RED}⦻--------------------------------------------------------⦻"
	echo -e "    | Erreur : Le nombre d'arguments ne doit pas dépasser 4! |"
	echo -e "    ⦻--------------------------------------------------------⦻\n${NC}"
	echo -e "    ${BLUE}✻--------------------------------✻"
	echo -e "    | Bienvenue dans l'espace d'aide |"
	echo -e "    ✻--------------------------------✻\n${NC}"
	echo -e "    ${YELLOW}Ⅰ Il vous faut d'abord avoir un fichier à traiter dans le dossier Input/"
        echo -e "    Ⅱ Puis exécuter le fichier shell nommé c-wire.sh puis passer en 1er argument le chemin de votre fichier"
	echo -e "    Ⅲ Par exemple Input/c-wire_v00.dat puis en 2ème et 3ème l'une des possibilités suivantes : hvb comp, hva comp, lv all, lv comp, lv indiv."
	echo -e "    Ⅳ Enfin vous pouvez rajouter un 4ème argument pour filtrer en fonction d'une centrale précise.\n${NC}"
	echo -e "    ${GREEN}☺ Par exemple : /c-wire.sh Input/c-wire_v25.dat lv all 1\n${NC}"
	exit 1
fi

#Checking the presence of the file passed as a parameter in the Input/ folder 
if [ ! -f "$file" ]; then
	echo -e "    ${RED}⦻--------------------------------------------------------------------------------------"
	echo -e "    | Erreur : Le fichier spécifié \"$file\" n'existe pas dans le dossier Input! |"
	echo -e "    ⦻--------------------------------------------------------------------------------------⦻${NC}"
	echo -e "    ${BLUE}✻--------------------------------✻"
	echo -e "    | Bienvenue dans l'espace d'aide |"
	echo -e "    ✻--------------------------------✻\n${NC}"
	echo -e "    ${YELLOW}Ⅰ Il vous faut d'abord avoir un fichier à traiter dans le dossier Input/"
        echo -e "    Ⅱ Puis exécuter le fichier shell nommé c-wire.sh puis passer en 1er argument le chemin de votre fichier"
	echo -e "    Ⅲ Par exemple Input/c-wire_v00.dat puis en 2ème et 3ème l'une des possibilités suivantes : hvb comp, hva comp, lv all, lv comp, lv indiv."
	echo -e "    Ⅳ Enfin vous pouvez rajouter un 4ème argument pour filtrer en fonction d'une centrale précise.\n${NC}"
	echo -e "    ${GREEN}☺ Par exemple : /c-wire.sh Input/c-wire_v25.dat lv all 1\n${NC}"
	exit 1
fi

#All the filter functions from  original file to file which will be sent to c code 
function hvbcomp {
	tail -n +2 "$tmp_file"  | cut -d ';' -f 2- | awk -F';' '{ if($1 !~ /-/ && $2 ~ /-/ ) print $1, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"

}

function hvacomp {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($2 !~ /-/ && $3 ~ /-/) print $2, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}


function lvall {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/) print $3, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}
	
function lvcomp {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/ && $5 ~ /-/ ) print $3, $(NF-1), $NF }'| awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}

function lvindiv {
	tail -n +2 "$tmp_file" | cut -d ';' -f 2- | awk -F';' '{ if($3 !~ /-/ && $4 ~ /-/) print $3, $(NF-1), $NF }' | awk '{ for (i=1; i<=NF; i++) if ($i == "-") $i = 0; print }' > "$tmp_file2"
}

#Checking temporary and graphic folders

if [ -d "$tmp" ]; then
	if [ -n "$(ls -A "$tmp")" ]; then
		rm -rf "$tmp"/*
	fi
else
	mkdir "$tmp"
fi

if [ ! -d "$graphs" ]; then
	mkdir "$graphs"
fi

#Compilation and verification that everything went well

cd "CodeC" || { echo -e "${RED}Impossible d'accéder au dossier CodeC${NC}"; exit 1; }
make
if [ $? -ne 0 ]; then
	echo -e "    ${RED}⦻--------------------------------⦻"
	echo -e "    | Erreur de compilation!         |\n    | Temps de traitement : 0s 0ms   |"
	echo -e "    ⦻--------------------------------⦻\n${NC}"

	exit 1
fi

clear

echo -e "${YELLOW}     ____"
echo -e "    /  __)"
echo -e "    | /"
echo -e "    | |"
echo -e "    | \\__"
echo -e "    \____)"
echo ""

sleep 0.5
clear

echo "     ____"
echo "    /  __)"
echo "    | /     __"
echo "    | |    (__)"
echo "    | \\__"
echo "    \____)"
echo ""

sleep 0.5
clear

echo -e "     ____      __          __"
echo -e "    /  __)     \\ \\        / /"
echo -e "    | /     __  \\ \\ /\\/\\ / /"
echo -e "    | |    (__)  \ V    V /"
echo -e "    | \\__         \\      /"
echo -e "    \____)         \\_/\\_/"
echo ""

sleep 0.5
clear

echo -e "     ____      __          __   _"
echo -e "    /  __)     \\ \\        / /  | |"
echo -e "    | /     __  \\ \\ /\\/\\ / /   | |"
echo -e "    | |    (__)  \\ V    V /    | |"
echo -e "    | \\__         \\      /     | |"
echo -e "    \____)         \\_/\\_/      |_|"
echo ""

sleep 0.5
clear

echo -e "     ____      __          __   _    ____"
echo -e "    /  __)     \\ \\        / /  | |  /  _ \\"
echo -e "    | /     __  \\ \\ /\\/\ / /   | |  | (_) |"
echo -e "    | |    (__)  \\ V    V /    | |  |    /"
echo -e "    | \\__         \\      /     | |  | |\ \\"
echo -e "    \____)         \\_/\\_/      |_|  |_| \_\\"
echo ""

sleep 0.5
clear

echo -e "     ____      __          __   _    ____     _____"
echo -e "    /  __)     \\ \\        / /  | |  /  _ \\   | ____|"
echo -e "    | /     __  \\ \\ /\\/\\ / /   | |  | (_) |  | |_"
echo -e "    | |    (__)  \\ V    V /    | |  |    /   | __|"
echo -e "    | \\__         \\      /     | |  | |\ \\   | |___"
echo -e "    \____)         \\_/\\_/      |_|  |_| \_\\  |_____|"
echo ""

sleep 0.5
clear

echo -e "     ____      __          __   _    ____     _____"
echo -e "    /  __)     \\ \\        / /  | |  /  _ \\   | ____|"
echo -e "    | /     __  \\ \\ /\\/\\ / /   | |  | (_) |  | |_"
echo -e "    | |    (__)  \\ V    V /    | |  |    /   | __|"
echo -e "    | \\__         \\      /     | |  | |\ \\   | |___     __   __   __"
echo -e "    \\____)         \\_/\\_/      |_|  |_| \_\\  |_____|   (__) (__) (__)${NC}"
echo ""

cd ..

chmod +x ./CodeC/exec

start_time=$(date +%s%3N)

if [ -n "$4" ]; then
	#Checking for presence of central number $4 in the file
	#Run grep and fill the temporary file
    	grep "^$4;" "$file" > "$tmp_file"
    
    	#Check if the temporary file is empty
    	if [ -s "$tmp_file" ]; then
       		echo ""
	else
		echo -e "${RED}Erreur : Le numéro de centrale $4 n'est pas présent dans le fichier!${NC}"
		exit 1
	fi
else
	tmp_file="$1"

fi

#The switch case that allows us to manage the options
case "$combined" in
"hvb-comp") hvbcomp;;
"hva-comp") hvacomp;;
"lv-all") lvall;;
"lv-comp") lvcomp;;
"lv-indiv") lvindiv;;
*) 
echo -e "    ${RED}⦻--------------------------------⦻"
echo -e "    | Mauvaise saisie des arguments! |\n    | Temps de traitement : 0s 0ms   |"
echo -e "    ⦻--------------------------------⦻\n${NC}"
echo -e "    ${BLUE}✻--------------------------------✻"
echo -e "    | Bienvenue dans l'espace d'aide |"
echo -e "    ✻--------------------------------✻\n${NC}"
echo -e "    ${YELLOW}Ⅰ Il vous faut d'abord avoir un fichier à traiter dans le dossier Input/"
echo -e "    Ⅱ Puis exécuter le fichier shell nommé c-wire.sh puis passer en 1er argument le chemin de votre fichier"
echo -e "    Ⅲ Par exemple Input/c-wire_v00.dat puis en 2ème et 3ème l'une des possibilités suivantes : hvb comp, hva comp, lv all, lv comp, lv indiv."
echo -e "    Ⅳ Enfin vous pouvez rajouter un 4ème argument pour filtrer en fonction d'une centrale précise.\n${NC}"
echo -e "    ${GREEN}☺ Par exemple : /c-wire.sh Input/c-wire_v25.dat lv all 1\n${NC}"
exit;;
esac


./CodeC/exec "$tmp_file2" "$combined"


#Sorts the file in the lv all case to get the 10 most and least loaded stations and produces the corresponding graph
if [ "$combined" = "lv-all" ]; then
	touch tmp/sorted.txt
	sort -k4,4n Output/calc_lv-all.txt > tmp/sorted.txt
	touch tmp/smallest.txt
	touch tmp/largest.txt
	touch Output/result.txt
	head -n 10 tmp/sorted.txt > tmp/smallest.txt
	tail -n 10 tmp/sorted.txt > tmp/largest.txt
	cat tmp/smallest.txt tmp/largest.txt > Output/result.txt
	# Génération du graphique
	chmod 777 plot.gnuplot
	chmod 777 Output/result.txt
	chmod 777 graphs
	gnuplot plot.gnuplot
	if [ -n "$4" ]; then
		mv graphs/bar_chart.png graphs/lv_all_minmax_$4_graph.png
		mv Output/result.txt Output/lv_all_minmax_$4.txt
	else
		mv graphs/bar_chart.png graphs/lv_all_minmax_graph.png
	fi
	echo -e "    ${BLUE}✻-------------------------------------------------✻"
	echo -e "    | Le graphique a été placé dans le dossier graphs |"
	echo -e "    ✻-------------------------------------------------✻\n${NC}"

fi


#Sort the output file by increasing capacity and rename it
if [ "$combined" ]; then
	sort -n -k3 -T /tmp Output/calc_$combined.txt -o Output/calc_$combined.txt
	if [ -n "$4" ]; then
		mv Output/calc_$combined.txt Output/${combined}_$4.txt
	else
		mv Output/calc_$combined.txt Output/$combined.txt
	fi	
	echo -e "    ${YELLOW}✻---------------------------------------------------------✻"
	echo -e "    | Le fichier de sortie a été placé dans le dossier Output |"
	echo -e "    ✻---------------------------------------------------------✻\n${NC}"

fi

end_time=$(date +%s%3N)
execution_time=$((end_time - start_time))
seconds=$((execution_time / 1000))
milliseconds=$((execution_time % 1000))
echo -e "${YELLOW}    ⌛ Temps de traitement : ${seconds}s ${milliseconds}ms ⌛${NC}"
echo ""